import Link from "next/link";
import { createClient } from "@/lib/supabase-server";

const money = (n: number) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);
const labels: Record<string,string> = { pending: "Menunggu pembayaran", paid: "Sudah dibayar", processing: "Diproses", completed: "Selesai", cancelled: "Dibatalkan", refunded: "Dikembalikan" };

export default async function OrdersPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return <main className="auth-wrap"><section className="auth-card"><h1>Login diperlukan</h1><Link className="plain-link" href="/login?next=/orders">Masuk untuk melihat pesanan</Link></section></main>;
  const { data: orders, error } = await supabase.from("orders").select("id, service_name, amount_idr, status, created_at").eq("user_id", user.id).order("created_at", { ascending: false });
  return <main className="auth-wrap"><Link className="brand auth-brand" href="/"><span className="brand-mark">V</span><span>VAMOZ<span className="muted"> STORE</span></span></Link><section className="auth-card" style={{width:"min(680px,100%)"}}><div className="eyebrow">CUSTOMER PORTAL</div><h1>Riwayat pesanan</h1><p className="auth-sub">Pesanan yang terkait dengan akun {user.email}.</p>{error ? <p className="auth-message">Gagal memuat pesanan. Pastikan skema database sudah dipasang.</p> : !orders?.length ? <p className="auth-message">Belum ada pesanan. Katalog dan pembuatan pesanan melalui checkout perlu diaktifkan sebelum pesanan tampil di sini.</p> : <div className="data-list">{orders.map(o=><div className="data-row" key={o.id}><div><strong>{o.service_name}</strong><small>{new Date(o.created_at).toLocaleString("id-ID")} · {money(Number(o.amount_idr))}</small></div><span className="status">{labels[o.status] || o.status}</span></div>)}</div>}<p className="auth-back"><Link href="/">← Kembali ke beranda</Link></p></section></main>;
}
