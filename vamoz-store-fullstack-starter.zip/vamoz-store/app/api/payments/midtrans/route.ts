import { NextResponse } from "next/server";
import crypto from "node:crypto";

// Webhook skeleton. Configure MIDTRANS_SERVER_KEY only in server environment.
// Verify signature before changing an order; test in sandbox before production.
export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const serverKey = process.env.MIDTRANS_SERVER_KEY;
  if (!serverKey) return NextResponse.json({ error: "Payment gateway belum dikonfigurasi." }, { status: 503 });

  const required = ["order_id", "status_code", "gross_amount", "signature_key", "transaction_status"];
  if (!body || required.some((key) => body[key] === undefined)) {
    return NextResponse.json({ error: "Payload webhook tidak lengkap." }, { status: 400 });
  }

  const expected = crypto.createHash("sha512")
    .update(`${body.order_id}${body.status_code}${body.gross_amount}${serverKey}`)
    .digest("hex");
  const actual = String(body.signature_key);
  const valid = actual.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(actual), Buffer.from(expected));
  if (!valid) return NextResponse.json({ error: "Signature tidak valid." }, { status: 401 });

  // TODO: lookup order by trusted payment reference; validate amount/currency;
  // map settlement/capture to paid, pending to pending, deny/expire/cancel to cancelled.
  // Use a server-only DB client or a narrowly scoped RPC for status transitions.
  // Never trust browser redirects as proof of payment.
  return NextResponse.json({ received: true, verified: true, note: "Signature valid; status update belum diaktifkan." });
}
