import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const bodySchema = z.object({ serviceId: z.string().uuid() });

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Login diperlukan." }, { status: 401 });

  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Data pesanan tidak valid." }, { status: 400 });

  const { data: service, error: serviceError } = await supabase
    .from("services").select("id, name, price_idr, active").eq("id", parsed.data.serviceId).eq("active", true).single();
  if (serviceError || !service) return NextResponse.json({ error: "Layanan tidak ditemukan atau tidak aktif." }, { status: 404 });

  // Nominal diambil dari database, bukan dari browser.
  const { data: order, error } = await supabase.from("orders").insert({
    user_id: user.id,
    service_id: service.id,
    service_name: service.name,
    amount_idr: service.price_idr,
    status: "pending",
  }).select("id, service_name, amount_idr, status, created_at").single();

  if (error) return NextResponse.json({ error: "Pesanan gagal disimpan." }, { status: 500 });
  return NextResponse.json({ order }, { status: 201 });
}
