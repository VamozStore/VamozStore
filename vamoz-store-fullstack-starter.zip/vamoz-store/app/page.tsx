"use client";

import { useState } from "react";
import { ArrowUpRight, Check, Menu, MessageCircle, ShieldCheck, Sparkles, Zap } from "lucide-react";

const services = [
  { id: "garapan-basic", category: "GARAPAN DIGITAL", name: "Garapan Basic", description: "Bantuan pengerjaan kebutuhan digital sesuai ruang lingkup yang disepakati.", price: 50000, tag: "Mulai dari" },
  { id: "digital-media", category: "MEDIA DIGITAL", name: "Layanan Media Digital", description: "Konsultasi dan layanan aset media digital yang sah untuk dialihkan.", price: 75000, tag: "Pilihan fleksibel" },
  { id: "custom", category: "CUSTOM", name: "Garapan Custom", description: "Diskusikan kebutuhan, estimasi waktu, dan biaya sebelum pemesanan.", price: 0, tag: "Sesuai kebutuhan" },
];
const rupiah = (value: number) => value === 0 ? "Konsultasi" : new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const whatsapp = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "").replace(/\D/g, "");
  function order(name: string) {
    if (!whatsapp) { alert("Tambahkan nomor WhatsApp bisnis di .env.local terlebih dahulu."); return; }
    const message = `Halo Vamoz Store, saya ingin bertanya tentang ${name}. Mohon informasi detail dan prosesnya.`;
    window.open(`https://wa.me/${whatsapp}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  }
  return <main>
    <nav className="nav container">
      <a className="brand" href="#"><span className="brand-mark">V</span><span>VAMOZ<span className="muted"> STORE</span></span></a>
      <button className="mobile-menu" aria-label="Buka menu" onClick={() => setMenuOpen(!menuOpen)}><Menu size={21}/></button>
      <div className={`nav-links ${menuOpen ? "open" : ""}`}>
        <a href="#layanan" onClick={() => setMenuOpen(false)}>Layanan</a><a href="#proses" onClick={() => setMenuOpen(false)}>Cara kerja</a><a href="#kontak" onClick={() => setMenuOpen(false)}>Kontak</a>
        <a className="nav-login" href="/login">Masuk akun <ArrowUpRight size={15}/></a>
      </div>
    </nav>
    <section className="hero container">
      <div className="hero-copy">
        <div className="eyebrow"><span className="status-dot"/> DIGITAL SERVICE PARTNER</div>
        <h1>Garapan digitalmu, <span className="gradient-text">lebih terarah.</span></h1>
        <p className="hero-description">Vamoz Store membantu kebutuhan digital melalui proses yang transparan, komunikasi yang jelas, dan layanan yang disesuaikan dengan kebutuhanmu.</p>
        <div className="hero-actions"><a className="button button-primary" href="#layanan">Lihat layanan <ArrowUpRight size={17}/></a><button className="button button-secondary" onClick={() => order("konsultasi layanan") }><MessageCircle size={17}/> Konsultasi</button></div>
        <div className="hero-trust"><span><Check size={15}/> Detail layanan jelas</span><span><Check size={15}/> Dukungan personal</span></div>
      </div>
      <div className="hero-art"><div className="orb orb-one"/><div className="orb orb-two"/><div className="glass-card">
        <div className="card-top"><span className="mini-icon"><Sparkles size={17}/></span><span className="pill">VAMOZ / DIGITAL</span></div>
        <p className="card-label">YOUR DIGITAL PARTNER</p><h2>Make it<br/><span className="gradient-text">happen.</span></h2><div className="card-line"/><div className="card-bottom"><span>SMART · SIMPLE · DIGITAL</span><ArrowUpRight size={18}/></div>
      </div><div className="floating-chip"><span className="chip-icon"><Zap size={16}/></span><span><b>Digital, lebih simpel</b><small>Mulai dari kebutuhanmu</small></span></div><div className="art-caption">DESIGNED FOR YOUR NEXT MOVE <span>✳</span></div></div>
    </section>
    <section className="metrics container"><div><strong>01</strong><span>Pilih layanan</span></div><div><strong>02</strong><span>Konfirmasi detail</span></div><div><strong>03</strong><span>Pantau pesanan</span></div><div className="metric-note">Langkah sederhana.<br/>Pengalaman lebih nyaman.</div></section>
    <section id="layanan" className="section container">
      <div className="section-heading"><div><div className="eyebrow">KATALOG LAYANAN</div><h2>Pilih solusi <span className="gradient-text">yang tepat.</span></h2></div><p>Harga di bawah adalah contoh awal. Konfirmasi detail, ruang lingkup, dan ketentuan layanan sebelum melakukan pembayaran.</p></div>
      <div className="service-grid">{services.map((s, i) => <article key={s.id} className={`service-card ${i===1?"featured":""}`}><div className="service-top"><span className="service-icon">{i===0?<ShieldCheck size={20}/>:i===1?<Zap size={20}/>:<Sparkles size={20}/>}</span><span className="service-tag">{s.tag}</span></div><div className="service-category">{s.category}</div><h3>{s.name}</h3><p>{s.description}</p><div className="service-price">{rupiah(s.price)}{s.price>0&&<small> / paket</small>}</div><button className="button button-card" onClick={()=>order(s.name)}>Tanya layanan <ArrowUpRight size={16}/></button></article>)}</div>
      <p className="disclaimer">Harga dan paket adalah contoh untuk rancangan awal. Ganti dengan penawaran resmi Vamoz Store sebelum publikasi.</p>
    </section>
    <section id="proses" className="feature-band"><div className="container feature-inner"><div><div className="eyebrow">CARA KERJA</div><h2>Fokus pada solusi.<br/><span className="gradient-text">Bukan kerumitan.</span></h2></div><div className="feature-list"><div><span>01</span><p><b>Pilih dan konsultasikan</b><small>Tentukan kebutuhan, detail pekerjaan, harga, dan estimasi waktu.</small></p></div><div><span>02</span><p><b>Buat pesanan</b><small>Pesanan tersimpan di akun agar statusnya bisa dilacak.</small></p></div><div><span>03</span><p><b>Pantau proses</b><small>Riwayat dan status pesanan dapat diakses dari portal pelanggan setelah fitur backend diaktifkan.</small></p></div></div></div></section>
    <section id="kontak" className="cta container"><div className="cta-glow"/><div className="eyebrow">LET'S TALK</div><h2>Punya kebutuhan digital?</h2><p>Ceritakan kebutuhanmu kepada tim Vamoz Store sebelum memesan.</p><button className="button button-primary" onClick={()=>order("konsultasi kebutuhan digital")}>Hubungi Vamoz Store <MessageCircle size={17}/></button></section>
    <footer className="footer"><div className="container footer-inner"><a className="brand" href="#"><span className="brand-mark">V</span><span>VAMOZ<span className="muted"> STORE</span></span></a><span>© {new Date().getFullYear()} Vamoz Store. All rights reserved.</span><a href="/orders">Riwayat pesanan <ArrowUpRight size={14}/></a></div></footer>
  </main>;
}
