import Link from "next/link";
import { createClient } from "@/lib/supabase-server";

const money = (n: number) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);
const labels: Record<string,string> = { pending: "Menunggu", paid: "Dibayar", processing: "Diproses", completed: "Selesai", cancelled: "Batal", refunded: "Refund" };

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: orders, error } = await supabase.from("orders").select("id, service_name, amount_idr, status, created_at").order("created_at", { ascending: false }).limit(50);
  const { count: serviceCount } = await supabase.from("services").select("*", { count: "exact", head: true });
  return <main className="auth-wrap"><Link className="brand auth-brand" href="/"><span className="brand-mark">V</span><span>VAMOZ<span className="muted"> STORE</span></span></Link><section className="auth-card" style={{width:"min(760px,100%)"}}><div className="eyebrow">ADMIN AREA · TERBATAS</div><h1>Dashboard admin</h1><p className="auth-sub">Sesi: {user?.email || "admin"}. Data dibaca dari database sesuai kebijakan akses Supabase.</p><div className="admin-placeholder"><div><span>Layanan terdaftar</span><b>{serviceCount ?? "—"}</b></div><div><span>Pesanan terbaru ditampilkan</span><b>{orders?.length ?? "—"}</b></div></div><h2 style={{fontSize:17}}>Pesanan terbaru</h2>{error ? <p className="auth-message">Gagal membaca pesanan. Periksa SQL dan kebijakan admin.</p> : !orders?.length ? <p className="auth-message">Belum ada data pesanan.</p> : <div className="data-list">{orders.map(o=><div className="data-row" key={o.id}><div><strong>{o.service_name}</strong><small>{new Date(o.created_at).toLocaleString("id-ID")} · {money(Number(o.amount_idr))}</small></div><span className="status">{labels[o.status] || o.status}</span></div>)}</div>}<p className="auth-message">Starter ini hanya menampilkan pesanan. Fitur ubah status dan CRUD layanan belum ditambahkan. Jangan pernah mengubah status pembayaran manual tanpa verifikasi provider.</p><p className="auth-back"><Link href="/">← Kembali ke beranda</Link></p></section></main>;
}
