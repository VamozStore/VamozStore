"use client";
import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase-browser";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setMessage(""); setBusy(true);
    try {
      const supabase = createClient();
      const result = mode === "login"
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password });
      if (result.error) throw result.error;
      if (mode === "login") {
        const next = searchParams.get("next");
        const safeNext = next && next.startsWith("/") && !next.startsWith("//") ? next : "/orders";
        router.replace(safeNext); router.refresh();
      } else {
        setMessage("Pendaftaran dikirim. Periksa email untuk konfirmasi jika fitur konfirmasi email diaktifkan.");
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Terjadi kesalahan. Periksa konfigurasi Supabase.");
    } finally { setBusy(false); }
  }

  return <main className="auth-wrap"><Link className="brand auth-brand" href="/"><span className="brand-mark">V</span><span>VAMOZ<span className="muted"> STORE</span></span></Link><section className="auth-card"><div className="eyebrow">CUSTOMER PORTAL</div><h1>{mode === "login" ? "Selamat datang." : "Buat akun."}</h1><p className="auth-sub">{mode === "login" ? "Masuk untuk melihat pesanan dan profilmu." : "Daftar untuk mulai menggunakan layanan kami."}</p><div className="auth-tabs"><button type="button" className={mode === "login" ? "active" : ""} onClick={() => {setMode("login");setMessage("");}}>Masuk</button><button type="button" className={mode === "signup" ? "active" : ""} onClick={() => {setMode("signup");setMessage("");}}>Daftar</button></div><form onSubmit={submit} className="auth-form"><label>Email<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="nama@email.com"/></label><label>Password<input type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={8} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Minimal 8 karakter"/></label><button className="button button-primary auth-submit" disabled={busy}>{busy ? "Memproses..." : mode === "login" ? "Masuk ke akun" : "Buat akun"}</button></form>{message && <p className="auth-message" role="status">{message}</p>}<p className="auth-back"><Link href="/">← Kembali ke halaman utama</Link></p></section><p className="auth-foot">Vamoz Store · Digital services</p></main>;
}
