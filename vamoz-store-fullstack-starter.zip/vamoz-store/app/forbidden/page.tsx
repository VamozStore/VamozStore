import Link from "next/link";
export default function ForbiddenPage() {
  return <main className="auth-wrap"><section className="auth-card"><div className="eyebrow">403 · AKSES DITOLAK</div><h1>Halaman terbatas.</h1><p className="auth-sub">Akun ini tidak memiliki hak akses admin.</p><Link className="button button-primary auth-submit" href="/">Kembali ke beranda</Link></section></main>;
}
