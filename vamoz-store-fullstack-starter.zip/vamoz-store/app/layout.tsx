import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Vamoz Store — Digital Services",
  description: "Garapan digital dan layanan digital dengan proses pemesanan yang jelas.",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
