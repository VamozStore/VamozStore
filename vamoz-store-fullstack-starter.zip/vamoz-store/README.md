# Vamoz Store Full-stack Starter (Android-friendly)

Starter website jasa digital: katalog garapan dan media digital, WhatsApp, Supabase login/signup, halaman riwayat pesanan, admin guard berbasis role, API pembuatan pesanan, skema database, serta kerangka webhook Midtrans.

## Penting: status implementasi
- Sudah ada: landing page responsif, katalog contoh, WhatsApp CTA, login/daftar Supabase, halaman riwayat pesanan, API pembuatan pesanan dengan harga diambil dari DB, guard sesi dan role admin, skema SQL dengan RLS, validasi signature webhook Midtrans.
- Belum selesai: halaman checkout Midtrans (Snap/token), webhook belum memperbarui status pesanan, kebijakan admin untuk membaca pesanan belum dibuat, CRUD layanan admin belum dibuat, tombol katalog belum membuat pesanan langsung. Jangan menerima pembayaran live sampai bagian ini dilengkapi dan diuji.

## Cara coding dari HP Android
Pilihan termudah: GitHub Codespaces melalui browser.
1. Buat akun GitHub jika belum punya.
2. Buat repository baru bernama `vamoz-store`.
3. Upload isi folder proyek ini ke repository (atau upload ZIP lalu ekstrak di lingkungan Codespaces).
4. Buka repository > tombol `Code` > tab `Codespaces` > `Create codespace on main`.
5. Setelah terminal Codespaces siap, jalankan:
   ```bash
   npm install
   npm run dev
   ```
6. Buka tab **Ports**, cari port `3000`, lalu pilih **Open in Browser**. Untuk preview dari HP, Codespaces perlu dijalankan dan port bisa disetel private/public sesuai kebutuhan. Jangan membagikan port publik jika situs berisi data sensitif.
7. Simpan perubahan dengan Git commit. Hindari memasukkan `.env.local` ke repository.

Alternatif: editor cloud lain yang mendukung Next.js, terminal Node, environment variables, dan port preview.

## Setup Supabase
1. Buat proyek di https://supabase.com.
2. Buka Project Settings > API, salin Project URL dan anon/public key.
3. Buat `.env.local` dari `.env.example` dan isi:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_WHATSAPP_NUMBER` (nomor format internasional, angka saja, contoh 6281234567890)
4. Di Supabase SQL Editor jalankan `supabase/schema.sql`.
5. Authentication > URL Configuration: tambahkan URL preview dan domain produksi ke allowed redirect URLs.
6. Buat akun admin lewat form daftar seperti biasa. Lalu buka Authentication > Users, salin UUID akun yang benar, dan jalankan di SQL Editor:
   ```sql
   update public.profiles
   set role = 'admin'
   where id = 'UUID-AKUN-ADMIN-YANG-TERVERIFIKASI';
   ```
   Jangan beri role admin melalui form publik. Jika `profiles` belum terisi, cek trigger `handle_new_user` dan buat profil secara aman di SQL Editor.

## Seed katalog contoh
Setelah menjalankan schema, masukkan layanan yang ingin ditampilkan:
```sql
insert into public.services (name, slug, category, description, price_idr, active)
values
('Garapan Basic', 'garapan-basic', 'garapan', 'Paket garapan digital basic', 50000, true),
('Layanan Media Digital', 'layanan-media-digital', 'media', 'Layanan aset digital yang sah dialihkan', 75000, true),
('Garapan Custom', 'garapan-custom', 'custom', 'Harga setelah konsultasi', 0, true);
```
Ubah harga dan deskripsi menjadi penawaran resmi. Katalog publik pada homepage masih menggunakan data contoh hardcoded; menghubungkan katalog ke tabel `services` adalah langkah berikutnya.

## Payment Indonesia: Midtrans
1. Daftar akun merchant di Midtrans dan mulai dari sandbox.
2. Isi `MIDTRANS_SERVER_KEY`, `MIDTRANS_CLIENT_KEY`, `MIDTRANS_IS_PRODUCTION=false`, dan `APP_BASE_URL` di server environment.
3. Implementasikan endpoint server untuk membuat transaksi Snap dengan order ID unik dari DB, nominal yang dihitung server, serta deskripsi layanan.
4. Atur Payment Notification URL ke `/api/payments/midtrans`.
5. Webhook di proyek ini memvalidasi signature SHA-512 tetapi **belum memperbarui status pesanan**. Sebelum produksi, implementasikan lookup payment_reference, validasi gross_amount/currency/status, update status melalui akses server tepercaya, dan idempotensi. Uji settlement, pending, expire, cancel, deny, refund, notifikasi berulang, dan pembayaran ganda.
6. Jangan pernah menandai pesanan lunas berdasarkan redirect browser. Jangan taruh server key di `NEXT_PUBLIC_*`.

## Keamanan yang wajib sebelum live
- RLS untuk admin membaca semua pesanan dan CRUD layanan sudah dicontohkan melalui fungsi `is_admin()`. Uji dengan akun customer/admin terpisah sebelum produksi.
- Tambahkan pembatasan laju pada login dan endpoint order.
- Jangan menyimpan password, OTP, atau kredensial media sosial pelanggan dalam tabel pesanan.
- Jangan gunakan akun yang dicuri, hasil phishing, atau aset yang dilarang untuk dialihkan oleh platform.
- Jalankan `npm run build`, tes RLS menggunakan akun customer/admin berbeda, dan audit callback pembayaran sebelum launch.

## Deploy
Vercel dapat dipakai untuk Next.js. Tambahkan environment variables di Project Settings > Environment Variables, lalu deploy. Pastikan domain produksi masuk ke URL Configuration Supabase dan URL notifikasi Midtrans sudah sesuai.
