create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  category text not null default 'digital',
  description text not null default '',
  price_idr bigint not null default 0 check (price_idr >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  service_id uuid references public.services(id) on delete set null,
  service_name text not null,
  amount_idr bigint not null check (amount_idr >= 0),
  status text not null default 'pending' check (status in ('pending','paid','processing','completed','cancelled','refunded')),
  payment_provider text,
  payment_reference text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists orders_user_created_idx on public.orders(user_id, created_at desc);
create index if not exists orders_status_idx on public.orders(status);
alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.orders enable row level security;

-- SECURITY DEFINER avoids recursive RLS checks when policies need to verify admin role.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'admin'
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

drop policy if exists "Anyone can view active services" on public.services;
create policy "Anyone can view active services" on public.services for select using (active = true);

drop policy if exists "Users view own profile" on public.profiles;
create policy "Users view own profile" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id and role = 'customer');

drop policy if exists "Users view own orders" on public.orders;
create policy "Users view own orders" on public.orders for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Admins view all orders" on public.orders;
create policy "Admins view all orders" on public.orders for select to authenticated using ((select public.is_admin()));
drop policy if exists "Users create own pending orders" on public.orders;
create policy "Users create own pending orders" on public.orders for insert to authenticated
with check (auth.uid() = user_id and status = 'pending' and payment_reference is null and payment_provider is null);

drop policy if exists "Admins insert services" on public.services;
create policy "Admins insert services" on public.services for insert to authenticated
with check ((select public.is_admin()));
drop policy if exists "Admins update services" on public.services;
create policy "Admins update services" on public.services for update to authenticated
using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy if exists "Admins delete services" on public.services;
create policy "Admins delete services" on public.services for delete to authenticated
using ((select public.is_admin()));

-- Admin role must be assigned manually by project owner in Supabase SQL Editor after
-- confirming the correct auth.users UUID. Never allow public signup to choose their role.
-- Example, replace UUID with the verified user's auth.users id:
-- update public.profiles set role='admin' where id='YOUR-VERIFIED-USER-UUID';
--
-- Create profile rows automatically on signup; role is always customer.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name, role)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name',''), 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT:
-- 1) No client policy lets a user mark an order paid.
-- 2) Do not add a broad UPDATE policy for orders.
-- 3) Webhook status updates must use server-only credentials or a narrowly scoped RPC.
-- 4) Never expose Supabase service_role key or Midtrans server key in browser variables.
-- 5) Add tested admin-only policies for order reads and service management before production.
