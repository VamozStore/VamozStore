import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({ request });
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return response;

  const supabase = createServerClient(url, key, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });

  const { data: { user } } = await supabase.auth.getUser();
  if (request.nextUrl.pathname.startsWith("/orders") && !user) {
    const target = request.nextUrl.clone();
    target.pathname = "/login";
    target.searchParams.set("next", "/orders");
    return NextResponse.redirect(target);
  }
  if (request.nextUrl.pathname.startsWith("/admin")) {
    if (!user) {
      const target = request.nextUrl.clone();
      target.pathname = "/login";
      target.searchParams.set("next", "/admin");
      return NextResponse.redirect(target);
    }
    const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
    if (profile?.role !== "admin") {
      const target = request.nextUrl.clone();
      target.pathname = "/forbidden";
      target.search = "";
      return NextResponse.redirect(target);
    }
  }
  return response;
}

export const config = { matcher: ["/orders/:path*", "/admin/:path*"] };
